/* HealthyWorld figure engine: a 2D side-view mannequin with keyframe animation.
   Runs in Node (build-time thumbnails) and in the browser (live simulations).

   WORLD: units are "body heights" (a standing figure is about 1.0 tall). x is to the right (the figure FACES +x),
   y is UP, the floor is y = 0. Every pose is drawn in this space; the camera fits itself to the figure.

   ANGLES (degrees)
     limbs  (arm/leg/foot): 0 = straight down, 90 = pointing forward (+x), 180 = straight up, -90 = backward.
     torso / head:          t = lean from vertical: 0 = upright, 90 = horizontal pointing forward (+x), 180 = hanging down,
                            negative = leaning back.

   A POSE is { loop: seconds, mat: bool, props: [...], frames: [...], thumb: seconds (optional) }.
   A FRAME (keyframe) is an object with these keys (all optional except `at` and one of p / s):
     at   : time in seconds (0 <= at < loop). The loop closes automatically back to the first frame.
     ph   : label for the segment that STARTS at this frame: 'in' | 'out' | 'hold' | 'down' | 'up' | 'rest' | 'switch'
     p    : [x,y] pelvis position.         s : [x,y] shoulder position (use p OR s, the same one in every frame of a pose)
     t    : torso lean (lower half).  sp : extra bend of the upper half of the torso (spine curve), default 0.
     h    : head tilt relative to the upper torso (+ = chin down / looking down, - = looking up). default 0.
     A    : near arm.  B : far arm (default = A).   M : far leg (default = L).   L : near leg.
            Each limb is EITHER  [a1, a2]  = forward kinematics (upper segment angle, lower segment angle)
            OR                   [x, y, b] = inverse kinematics, the wrist/ankle goes to world point (x,y);
                                 b = +1 bends the joint counter-clockwise from the line hip->ankle (knee forward for a
                                 standing leg), b = -1 the other way (elbow backward for an arm hanging down / pushing).
            A limb must use the same kind (FK or IK) in every frame of one pose.
     k    : body scale (default 1; a child is about 0.62). Positions you give are in world units, so scale p / targets yourself.
     F, G : near / far foot angle (default 90 = flat, toes forward; 0 = toes straight down, -90 = toes point backward)
*/
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.HWFig = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';
  var R = Math.PI / 180;
  var LEN = { tor: 0.30, ua: 0.165, fa: 0.150, th: 0.245, sh: 0.245, ft: 0.10, nk: 0.045, hd: 0.062 };
  var WID = { tor: 0.095, ua: 0.046, fa: 0.040, th: 0.068, sh: 0.054, ft: 0.040, nk: 0.034 };
  var COL = { near: '#2B7A68', far: '#8DB5AA', ground: '#CDD5D3', mat: '#D5DFDC', prop: '#CBD3D1', propDark: '#B5BFBC', shadow: 'rgba(27,40,38,.09)', skin: '#EBCFB2', skinFar: '#D9BFA4', hair: '#38403E' };
  var DX = 0.016;          // far-side limbs are drawn a little forward so they peek out from behind
  var HAND = 0.026;

  function up(a) { return [Math.sin(a * R), Math.cos(a * R)]; }
  function dn(a) { return [Math.sin(a * R), -Math.cos(a * R)]; }
  function add(p, v, l) { return [p[0] + v[0] * l, p[1] + v[1] * l]; }
  function f3(n) { return (Math.round(n * 1000) / 1000).toString(); }

  function ik(o, tx, ty, l1, l2, b) {
    var dx = tx - o[0], dy = ty - o[1], d = Math.hypot(dx, dy) || 1e-6, base = Math.atan2(dy, dx);
    var max = (l1 + l2) * 0.9995, min = Math.abs(l1 - l2) + 1e-4, dc = Math.min(Math.max(d, min), max);
    var c = (l1 * l1 + dc * dc - l2 * l2) / (2 * l1 * dc), A = Math.acos(Math.max(-1, Math.min(1, c)));
    var a = base + (b >= 0 ? A : -A);
    var mid = [o[0] + l1 * Math.cos(a), o[1] + l1 * Math.sin(a)];
    var end = (d <= max && d >= min) ? [tx, ty] : [o[0] + dc * Math.cos(base), o[1] + dc * Math.sin(base)];
    return [mid, end];
  }
  function limb(o, l1, l2, s) {
    if (s.length === 3) return ik(o, s[0], s[1], l1, l2, s[2]);
    var m = add(o, dn(s[0]), l1);
    return [m, add(m, dn(s[1]), l2)];
  }
  function shiftSpec(s) { return s.length === 3 ? [s[0] + DX, s[1], s[2]] : s.slice(); }

  function norm(f) {
    var g = Object.assign({}, f);
    g.t = g.t || 0; g.sp = g.sp || 0; g.h = g.h || 0; g.k = g.k || 1;
    g.F = g.F == null ? 90 : g.F;
    g.A = g.A || [0, 0]; g.L = g.L || [0, 0.02, 1];
    g.B = g.B || shiftSpec(g.A); g.M = g.M || shiftSpec(g.L);
    g.G = g.G == null ? g.F : g.G;
    return g;
  }
  function prep(pose) {
    if (pose._p) return pose._p;
    var fr = pose.frames.map(norm).sort(function (a, b) { return a.at - b.at; });
    if (pose.closed !== false) { var c = Object.assign({}, fr[0]); c.at = pose.loop; fr.push(c); }
    pose._p = fr;
    return fr;
  }
  function lerp(a, b, e) {
    var o = {};
    Object.keys(a).forEach(function (k) {
      var x = a[k], y = b[k];
      if (typeof x === 'number' && typeof y === 'number') o[k] = x + (y - x) * e;
      else if (Array.isArray(x) && Array.isArray(y) && x.length === y.length) o[k] = x.map(function (v, i) { return v + (y[i] - v) * e; });
      else o[k] = x;
    });
    return o;
  }
  function sample(pose, tau) {
    var fr = prep(pose), L = pose.loop;
    tau = ((tau % L) + L) % L;
    var i = 0;
    while (i < fr.length - 2 && tau >= fr[i + 1].at) i++;
    var a = fr[i], b = fr[i + 1], span = (b.at - a.at) || 1, u = Math.min(1, Math.max(0, (tau - a.at) / span));
    var out = lerp(a, b, u * u * (3 - 2 * u));
    out.ph = a.ph || 'hold';
    return out;
  }

  function solve(f) {
    var k = f.k || 1, tor = LEN.tor * k, half = tor / 2, v1 = up(f.t), v2 = up(f.t + f.sp), P;
    var hr = LEN.hd * (k + (1 - k) * 0.45), nk = LEN.nk * k;
    if (f.s) P = [f.s[0] - (v1[0] + v2[0]) * half, f.s[1] - (v1[1] + v2[1]) * half];
    else P = f.p || [0, 0.51 * k];
    var M = add(P, v1, half), S = add(M, v2, half), hv = up(f.t + f.sp + f.h);
    var H = add(S, hv, nk + hr), N = add(S, hv, nk);
    var dx = DX * k, Sf = [S[0] + dx, S[1]], Pf = [P[0] + dx, P[1]];
    var armN = limb(S, LEN.ua * k, LEN.fa * k, f.A), armF = limb(Sf, LEN.ua * k, LEN.fa * k, f.B);
    var legN = limb(P, LEN.th * k, LEN.sh * k, f.L), legF = limb(Pf, LEN.th * k, LEN.sh * k, f.M);
    return {
      P: P, M: M, S: S, N: N, H: H, k: k, hr: hr, armN: armN, armF: armF, legN: legN, legF: legF,
      toeN: add(legN[1], dn(f.F), LEN.ft * k), toeF: add(legF[1], dn(f.G), LEN.ft * k)
    };
  }

  function pts(J) {
    return [J.P, J.M, J.S, J.H, J.armN[0], J.armN[1], J.armF[0], J.armF[1], J.legN[0], J.legN[1], J.legF[0], J.legF[1], J.toeN, J.toeF];
  }

  /* camera that fits the whole loop, with the floor kept in view; cached on the pose */
  function viewOf(pose) {
    if (pose.view) return pose.view;
    if (pose._v) return pose._v;
    var x0 = 1e9, x1 = -1e9, y0 = 0, y1 = -1e9, n = 36, i, k, p, J, fr;
    for (i = 0; i < n; i++) {
      fr = sample(pose, pose.loop * i / n); J = solve(fr);
      pts(J).forEach(function (q) { x0 = Math.min(x0, q[0]); x1 = Math.max(x1, q[0]); y1 = Math.max(y1, q[1]); y0 = Math.min(y0, q[1]); });
      y1 = Math.max(y1, J.H[1] + LEN.hd);
    }
    (pose.props || []).forEach(function (pr) {
      if (pr.k === 'wall') { x1 = Math.max(x1, pr.x + 0.08); }
      if (pr.k === 'chair') { x0 = Math.min(x0, pr.x0); x1 = Math.max(x1, pr.x1); y1 = Math.max(y1, pr.h + (pr.back ? 0.35 : 0)); }
    });
    var pad = 0.12, aspect = 1.4;
    var w = Math.max(x1 - x0 + 2 * pad, 1.1), h = Math.max(y1 - Math.min(y0, 0) + 2 * pad, 0.85);
    if (w / h < aspect) w = h * aspect; else h = w / aspect;
    var cx = (x0 + x1) / 2, vx = cx - w / 2, floorPad = Math.min(0.16, h * 0.12);
    var vy = -(Math.max(y1 + pad, h - floorPad));       // top of view in svg coords (y flipped)
    var v = [vx, Math.min(vy, -(h - floorPad)), w, h];
    pose._v = v;
    return v;
  }

  function seg(a, b, w, c) {
    return '<path d="M' + f3(a[0]) + ' ' + f3(-a[1]) + 'L' + f3(b[0]) + ' ' + f3(-b[1]) + '" stroke="' + c + '" stroke-width="' + w + '" stroke-linecap="round" fill="none"/>';
  }
  function dot(p, r, c) { return '<circle cx="' + f3(p[0]) + '" cy="' + f3(-p[1]) + '" r="' + r + '" fill="' + c + '"/>'; }
  function rect(x, y, w, h, c, rx) { return '<rect x="' + f3(x) + '" y="' + f3(-(y + h)) + '" width="' + f3(w) + '" height="' + f3(h) + '" rx="' + (rx || 0) + '" fill="' + c + '"/>'; }

  function propsSvg(pose, v) {
    var s = '';
    (pose.props || []).forEach(function (pr) {
      if (pr.k === 'wall') s += rect(pr.x, 0, 0.12, v[3] + 0.3, COL.prop) + rect(pr.x, 0, 0.012, v[3] + 0.3, COL.propDark);
      else if (pr.k === 'chair') {
        var t = 0.035, lw = 0.03;
        s += rect(pr.x0, pr.h - t, pr.x1 - pr.x0, t, COL.propDark, 0.012);
        s += rect(pr.x0 + 0.01, 0, lw, pr.h - t, COL.prop) + rect(pr.x1 - lw - 0.01, 0, lw, pr.h - t, COL.prop);
        if (pr.back === 'left') s += rect(pr.x0, pr.h, 0.03, 0.34, COL.propDark, 0.012);
        if (pr.back === 'right') s += rect(pr.x1 - 0.03, pr.h, 0.03, 0.34, COL.propDark, 0.012);
      } else if (pr.k === 'cane') {
        s += seg([pr.x, 0.01], [pr.x, pr.h], 0.022, COL.propDark) + seg([pr.x, pr.h], [pr.x - 0.04, pr.h + 0.01], 0.022, COL.propDark);
      } else if (pr.k === 'cushion') s += rect(pr.x, 0, pr.w, pr.h, COL.propDark, pr.h / 2);
      else if (pr.k === 'block') s += rect(pr.x, 0, pr.w, pr.h, COL.propDark, 0.012);
    });
    return s;
  }

  function inner(fr, pose, v) {
    v = v || viewOf(pose);
    var J = solve(fr), s = '', k = J.k, wk = 0.55 + 0.45 * k, hs = J.hr / LEN.hd;
    s += '<path d="M' + f3(v[0] - 1) + ' 0H' + f3(v[0] + v[2] + 1) + '" stroke="' + COL.ground + '" stroke-width="0.014"/>';
    if (pose.mat) {
      var P = pts(J), mx0 = 1e9, mx1 = -1e9;
      P.forEach(function (q) { if (q[1] < 0.35) { mx0 = Math.min(mx0, q[0]); mx1 = Math.max(mx1, q[0]); } });
      mx0 = Math.min(mx0, (v[0] + v[2] / 2) - 0.45) - 0.12; mx1 = Math.max(mx1, (v[0] + v[2] / 2) + 0.45) + 0.12;
      if (pose.matRange) { mx0 = pose.matRange[0]; mx1 = pose.matRange[1]; }
      s += rect(mx0, -0.012, mx1 - mx0, 0.012, COL.mat, 0.006);
    }
    s += propsSvg(pose, v);
    var all = pts(J), minx = 1e9, maxx = -1e9;
    all.forEach(function (q) { minx = Math.min(minx, q[0]); maxx = Math.max(maxx, q[0]); });
    var cx = (minx + maxx) / 2, rx = Math.min(0.62, Math.max(0.13, (maxx - minx) * 0.5));
    s += '<ellipse cx="' + f3(cx) + '" cy="0.004" rx="' + f3(rx) + '" ry="0.016" fill="' + COL.shadow + '"/>';
    function arm(a, c) { return seg(arguments[2], a[0], (WID.ua * wk), c) + seg(a[0], a[1], (WID.fa * wk), c) + dot(a[1], HAND * k, c === COL.far ? COL.skinFar : COL.skin); }
    function leg(l, toe, c) { return seg(arguments[3], l[0], (WID.th * wk), c) + seg(l[0], l[1], (WID.sh * wk), c) + seg(l[1], toe, (WID.ft * wk), c); }
    var Sf = [J.S[0] + DX * k, J.S[1]], Pf = [J.P[0] + DX * k, J.P[1]];
    s += arm(J.armF, COL.far, Sf);
    s += leg(J.legF, J.toeF, COL.far, Pf);
    s += '<path d="M' + f3(J.P[0]) + ' ' + f3(-J.P[1]) + 'L' + f3(J.M[0]) + ' ' + f3(-J.M[1]) + 'L' + f3(J.S[0]) + ' ' + f3(-J.S[1]) + '" stroke="' + COL.near + '" stroke-width="' + (WID.tor * wk) + '" stroke-linecap="round" stroke-linejoin="round" fill="none"/>';
    var th = fr.t + fr.sp + fr.h, hv = up(th), fv = [Math.cos(th * R), -Math.sin(th * R)];
    s += seg(J.S, J.N, (WID.nk * wk), COL.skin);
    s += dot([J.H[0] - fv[0] * 0.008 + hv[0] * 0.008, J.H[1] - fv[1] * 0.008 + hv[1] * 0.008], 0.064 * hs, COL.hair);
    s += dot([J.H[0] + fv[0] * 0.010 - hv[0] * 0.004, J.H[1] + fv[1] * 0.010 - hv[1] * 0.004], 0.057 * hs, COL.skin);
    s += leg(J.legN, J.toeN, COL.near, J.P);
    s += arm(J.armN, COL.near, J.S);
    return s;
  }

  function svg(pose, tau, o) {
    o = o || {};
    var v = viewOf(pose), fr = sample(pose, tau == null ? (pose.thumb != null ? pose.thumb : 0) : tau);
    return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="' + v.map(f3).join(' ') + '"' + (o.cls ? ' class="' + o.cls + '"' : '') +
      (o.label ? ' role="img" aria-label="' + String(o.label).replace(/"/g, '&quot;') + '"' : ' aria-hidden="true"') +
      ' preserveAspectRatio="xMidYMax meet"><g>' + inner(fr, pose, v) + '</g></svg>';
  }

  function validate(pose) {
    var errs = [];
    if (!(pose.loop > 0)) errs.push('loop missing');
    if (!pose.frames || pose.frames.length < 2) errs.push('need at least 2 frames');
    else {
      var last = -1, usesS = !!pose.frames[0].s, kinds = {};
      pose.frames.forEach(function (f, i) {
        if (f.at == null || f.at < 0 || f.at >= pose.loop) errs.push('frame ' + i + ' has bad at');
        if (f.at <= last) errs.push('frame ' + i + ' at not ascending');
        last = f.at;
        if (!f.p && !f.s) errs.push('frame ' + i + ' needs p or s');
        if (!!f.s !== usesS) errs.push('frame ' + i + ' mixes p and s');
        ['A', 'B', 'L', 'M'].forEach(function (k) {
          if (!f[k]) return;
          if (f[k].length !== 2 && f[k].length !== 3) errs.push('frame ' + i + ' limb ' + k + ' bad length');
          if (kinds[k] == null) kinds[k] = f[k].length; else if (kinds[k] !== f[k].length) errs.push('frame ' + i + ' limb ' + k + ' mixes FK/IK');
        });
      });
    }
    return errs;
  }

  /* browser: animated stage */
  function mount(el, pose, o) {
    o = o || {};
    var st = { pose: pose, t: 0, speed: o.speed || 1, playing: false, raf: 0, last: 0, loops: 0, lastPh: null, acc: 0 };
    var g;
    function build() {
      var v = viewOf(st.pose);
      el.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="' + v.map(f3).join(' ') + '" preserveAspectRatio="xMidYMax meet" role="img" aria-label="' + (o.label || '').replace(/"/g, '&quot;') + '"><g></g></svg>';
      g = el.querySelector('g');
    }
    function draw() {
      var fr = sample(st.pose, st.t);
      g.innerHTML = inner(fr, st.pose);
      if (o.onphase && fr.ph !== st.lastPh) { st.lastPh = fr.ph; o.onphase(fr.ph); }
    }
    function tick(now) {
      if (!st.playing) return;
      var dt = Math.min(0.1, (now - st.last) / 1000); st.last = now;
      st.acc += dt;
      if (st.acc >= 1 / 40) {
        st.t += st.acc * st.speed; st.acc = 0;
        if (st.t >= st.pose.loop) { st.t -= st.pose.loop; st.loops++; if (o.onloop) o.onloop(st.loops); }
        draw();
      }
      st.raf = requestAnimationFrame(tick);
    }
    var api = {
      play: function () { if (st.playing) return; st.playing = true; st.last = performance.now(); st.raf = requestAnimationFrame(tick); if (o.onstate) o.onstate(true); },
      pause: function () { st.playing = false; cancelAnimationFrame(st.raf); if (o.onstate) o.onstate(false); },
      toggle: function () { st.playing ? api.pause() : api.play(); return st.playing; },
      speed: function (x) { st.speed = x; },
      set: function (p, label) { var was = st.playing; api.pause(); st.pose = p; st.t = 0; st.loops = 0; st.lastPh = null; if (label != null) o.label = label; build(); draw(); if (was || o.autoplay !== false) api.play(); },
      playing: function () { return st.playing; }
    };
    build(); draw();
    return api;
  }

  return { LEN: LEN, sample: sample, solve: solve, svg: svg, inner: inner, viewOf: viewOf, validate: validate, mount: mount, prep: prep, ik: ik };
});

;
// Still "portrait" figures for the six age groups (used as card art; they could be animated too).
globalThis.HWPOSES = Object.assign(globalThis.HWPOSES || {}, {
  // child: smaller, bigger head, cheering
  age1: { loop: 4, thumb: 1, frames: [
    { at: 0, k: 0.62, p: [0, 0.31], t: 0, h: -6, A: [150, 160], B: [128, 140], L: [-0.02, 0.02, 1], M: [0.07, 0.02, 1] },
    { at: 2, k: 0.62, p: [0, 0.31], t: -2, h: -8, A: [168, 172], B: [146, 152], L: [-0.02, 0.02, 1], M: [0.07, 0.02, 1] }
  ] },
  // teen: relaxed, one hand toward pocket
  age2: { loop: 4, thumb: 0, frames: [
    { at: 0, k: 0.88, p: [0, 0.447], t: -1, h: 0, A: [-6, 55], B: [10, 18], L: [0, 0.02, 1], M: [0.05, 0.02, 1] },
    { at: 2, k: 0.88, p: [0, 0.447], t: -2, h: 2, A: [-6, 55], B: [8, 14], L: [0, 0.02, 1], M: [0.05, 0.02, 1] }
  ] },
  // young adult: mid-stride walking
  age3: { loop: 4, thumb: 0, frames: [
    { at: 0, k: 0.97, p: [0, 0.482], t: 3, h: 0, A: [-30, -14], B: [34, 22], L: [0.11, 0.02, 1], M: [-0.11, 0.05, 1], F: 90, G: 55 },
    { at: 2, k: 0.97, p: [0, 0.482], t: 3, h: 0, A: [-30, -14], B: [34, 22], L: [0.11, 0.02, 1], M: [-0.11, 0.05, 1], F: 90, G: 55 }
  ] },
  // adult: calm, upright
  age4: { loop: 4, thumb: 0, frames: [
    { at: 0, k: 1, p: [0, 0.505], t: 0, h: 0, A: [10, 4], B: [-8, 2], L: [0, 0.02, 1], M: [0.04, 0.02, 1] },
    { at: 2, k: 1, p: [0, 0.505], t: 0, h: 0, A: [12, 6], B: [-6, 4], L: [0, 0.02, 1], M: [0.04, 0.02, 1] }
  ] },
  // mature adult: hand on hip
  age5: { loop: 4, thumb: 0, frames: [
    { at: 0, k: 0.99, p: [0, 0.5], t: 2, h: 0, A: [-38, 82], B: [6, 2], L: [0, 0.02, 1], M: [0.05, 0.02, 1] },
    { at: 2, k: 0.99, p: [0, 0.5], t: 3, h: 0, A: [-38, 82], B: [8, 4], L: [0, 0.02, 1], M: [0.05, 0.02, 1] }
  ], props: [] },
  // senior: gentle stoop with a cane
  age6: { loop: 4, thumb: 0, props: [{ k: 'cane', x: 0.2, h: 0.45 }], frames: [
    { at: 0, k: 0.95, p: [-0.02, 0.463], t: 14, sp: 6, h: 8, A: [0.2, 0.46, -1], B: [12, 8], L: [0, 0.02, 1], M: [-0.04, 0.02, 1] },
    { at: 2, k: 0.95, p: [-0.02, 0.463], t: 15, sp: 6, h: 8, A: [0.2, 0.46, -1], B: [10, 6], L: [0, 0.02, 1], M: [-0.04, 0.02, 1] }
  ] }
});

;
// 15 home exercises. Side-view mannequin, figure faces +x. See figure.js for the keyframe format.
(function () {
  var H = globalThis.HWPOSES = globalThis.HWPOSES || {};
  var J = function (o) { return Object.assign({ sp: 0, h: 0, F: 90, G: 90 }, o); };

  /* shared plank geometry: hands at x .30, ankles at x -.45 */
  var PK_UP = { p: [0.0135, 0.242], t: 72.7 };
  var PK_DN = { p: [0.039, 0.125], t: 87.1 };
  var PK = { h: -12, A: [0.30, 0.03, -1], B: [0.32, 0.03, -1], L: [-0.45, 0.10, 1], M: [-0.45, 0.10, 1], F: 0, G: 0 };

  H.wallpush = { loop: 3.4, mat: false, thumb: 1.6, props: [{ k: 'wall', x: 0.60 }], frames: [
    J({ at: 0,   ph: 'down', p: [0.197, 0.495], t: 18, h: 0, A: [0.60, 0.78, -1], B: [0.62, 0.78, -1], L: [0.04, 0.03, 1], M: [0.07, 0.03, 1] }),
    J({ at: 1.6, ph: 'up',   p: [0.247, 0.474], t: 25, h: 0, A: [0.60, 0.78, -1], B: [0.62, 0.78, -1], L: [0.04, 0.03, 1], M: [0.07, 0.03, 1] })
  ] };

  H.squat = { loop: 4.2, mat: false, thumb: 1.8, frames: [
    J({ at: 0,   ph: 'down', p: [0, 0.508],     t: 0,  h: 0,   A: [15, 15], L: [0, 0.025, 1], M: [0.04, 0.025, 1] }),
    J({ at: 1.8, ph: 'hold', p: [-0.18, 0.30],  t: 36, h: -12, A: [90, 90], L: [0, 0.025, 1], M: [0.04, 0.025, 1] }),
    J({ at: 2.4, ph: 'up',   p: [-0.18, 0.30],  t: 36, h: -12, A: [90, 90], L: [0, 0.025, 1], M: [0.04, 0.025, 1] })
  ] };

  var gl = { A: [0.0, 0.03, -1], B: [0.03, 0.03, -1], L: [0.30, 0.025, 1], M: [0.32, 0.025, 1] };
  H.glute = { loop: 5, mat: true, thumb: 2, frames: [
    J(Object.assign({ at: 0,   ph: 'up',   p: [0, 0.10], t: -92 }, gl)),
    J(Object.assign({ at: 1.6, ph: 'hold', p: [0, 0.34], t: -128 }, gl)),
    J(Object.assign({ at: 2.6, ph: 'down', p: [0, 0.34], t: -128 }, gl))
  ] };

  H.march = { loop: 2, mat: false, thumb: 0, frames: [
    { at: 0,   ph: 'up',   p: [0, 0.51], t: 2, h: 0, A: [-25, 10], B: [60, 40], L: [88, 5], M: [0, 0], F: 70 },
    { at: 0.5, ph: 'rest', p: [0, 0.51], t: 0, h: 0, A: [5, 15],   B: [5, 15],  L: [0, 0],  M: [0, 0] },
    { at: 1,   ph: 'up',   p: [0, 0.51], t: 2, h: 0, A: [60, 40],  B: [-25, 10], L: [0, 0], M: [88, 5], G: 70 },
    { at: 1.5, ph: 'rest', p: [0, 0.51], t: 0, h: 0, A: [5, 15],   B: [5, 15],  L: [0, 0],  M: [0, 0] }
  ] };

  var kp = { h: -20, A: [0.30, 0.03, -1], B: [0.33, 0.03, -1], L: [-49, -112], M: [-49, -112], F: -90, G: -90 };
  H.kneeplank = { loop: 5, mat: true, thumb: 0, frames: [
    J(Object.assign({ at: 0, ph: 'hold', s: [0.30, 0.33], t: 62 }, kp)),
    J(Object.assign({ at: 2.5, ph: 'hold', s: [0.30, 0.33], t: 60 }, kp))
  ] };

  H.pushup = { loop: 3.6, mat: true, thumb: 0, frames: [
    J(Object.assign({ at: 0,   ph: 'down' }, PK_UP, PK)),
    J(Object.assign({ at: 1.5, ph: 'hold' }, PK_DN, PK)),
    J(Object.assign({ at: 1.8, ph: 'up' }, PK_DN, PK))
  ] };

  var lg = { t: 0, h: 0, A: [10, 25], B: [-5, 15], L: [0.20, 0.025, 1], M: [-0.34, 0.04, 1], G: 30 };
  H.lunge = { loop: 3.6, mat: true, thumb: 1.5, frames: [
    J(Object.assign({ at: 0,   ph: 'down', p: [-0.04, 0.43] }, lg)),
    J(Object.assign({ at: 1.5, ph: 'hold', p: [-0.04, 0.27] }, lg)),
    J(Object.assign({ at: 2.0, ph: 'up',   p: [-0.04, 0.27] }, lg))
  ] };

  H.plank = { loop: 4, mat: true, thumb: 0, frames: [
    J(Object.assign({ at: 0, ph: 'hold', p: [0.0135, 0.242], t: 72.7 }, PK)),
    J(Object.assign({ at: 2, ph: 'hold', p: [0.0135, 0.246], t: 73.4 }, PK))
  ] };

  var mc = { p: PK_UP.p, t: PK_UP.t, h: -12, A: PK.A, B: PK.B, F: 0, G: 0 };
  H.climber = { loop: 1.6, mat: true, thumb: 0, frames: [
    J(Object.assign({ at: 0,   ph: 'switch', L: [0.05, 0.12, 1], M: [-0.45, 0.10, 1] }, mc)),
    J(Object.assign({ at: 0.8, ph: 'switch', L: [-0.45, 0.10, 1], M: [0.07, 0.12, 1] }, mc))
  ] };

  var dp = { h: 0, A: [-0.21, 0.42, -1], B: [-0.19, 0.42, -1], L: [0.12, 0.03, 1], M: [0.14, 0.03, 1] };
  H.dip = { loop: 3.6, mat: false, thumb: 0, props: [{ k: 'chair', x0: -0.58, x1: -0.18, h: 0.42, back: 'left' }], frames: [
    J(Object.assign({ at: 0,   ph: 'down', p: [-0.10, 0.43], t: 0 }, dp)),
    J(Object.assign({ at: 1.5, ph: 'hold', p: [-0.10, 0.21], t: 0 }, dp)),
    J(Object.assign({ at: 1.8, ph: 'up',   p: [-0.10, 0.21], t: 0 }, dp))
  ] };

  var bp = function (o) { return J(Object.assign({ L: [0, 0.025, 1], M: [0.04, 0.025, 1] }, o)); };
  H.burpee = { loop: 6, mat: true, thumb: 0, frames: [
    bp({ at: 0,   ph: 'down',   p: [0, 0.508], t: 0, h: 0, A: [0.03, 0.52, -1], B: [0.0, 0.50, -1] }),
    bp({ at: 0.9, ph: 'switch', p: [-0.14, 0.25], t: 75, h: -30, A: [0.28, 0.03, -1], B: [0.31, 0.03, -1] }),
    J({ at: 1.7, ph: 'hold', p: PK_UP.p, t: PK_UP.t, h: -12, A: PK.A, B: PK.B, L: [-0.45, 0.10, 1], M: [-0.45, 0.10, 1], F: 0, G: 0 }),
    J({ at: 2.4, ph: 'switch', p: PK_UP.p, t: PK_UP.t, h: -12, A: PK.A, B: PK.B, L: [-0.45, 0.10, 1], M: [-0.45, 0.10, 1], F: 0, G: 0 }),
    bp({ at: 3.3, ph: 'up',     p: [-0.14, 0.25], t: 75, h: -30, A: [0.28, 0.03, -1], B: [0.31, 0.03, -1] }),
    bp({ at: 4.3, ph: 'up',     p: [0, 0.76], t: 0, h: -10, A: [-0.02, 1.12, -1], B: [0.0, 1.12, -1], L: [0, 0.29, 1], M: [0.03, 0.30, 1], F: 40, G: 40 }),
    bp({ at: 5.2, ph: 'rest',   p: [0, 0.508], t: 0, h: 0, A: [0.03, 0.52, -1], B: [0.0, 0.50, -1] })
  ] };

  var jq = function (o) { return J(Object.assign({ L: [0, 0.025, 1], M: [0.04, 0.025, 1] }, o)); };
  H.jumpsquat = { loop: 3.4, mat: false, thumb: 1.55, frames: [
    jq({ at: 0,    ph: 'down', p: [0, 0.508],    t: 0,  h: 0,   A: [15, 15] }),
    jq({ at: 1.2,  ph: 'hold', p: [-0.18, 0.30], t: 36, h: -12, A: [-30, -20] }),
    jq({ at: 1.55, ph: 'up',   p: [0, 0.78],     t: 0,  h: -10, A: [165, 170], L: [0, 0.30, 1], M: [0.03, 0.31, 1], F: 40, G: 40 }),
    jq({ at: 2.0,  ph: 'down', p: [-0.10, 0.38], t: 20, h: -8,  A: [60, 60] }),
    jq({ at: 2.6,  ph: 'rest', p: [0, 0.508],    t: 0,  h: 0,   A: [15, 15] })
  ] };

  var pk = { h: 0, A: [0.32, 0.03, -1], B: [0.35, 0.03, -1], L: [-0.28, 0.03, 1], M: [-0.26, 0.03, 1] };
  H.pike = { loop: 3.6, mat: true, thumb: 0, frames: [
    J(Object.assign({ at: 0,   ph: 'down', p: [-0.06, 0.47], t: 150 }, pk)),
    J(Object.assign({ at: 1.5, ph: 'hold', p: [0.02, 0.40], t: 145, h: 25 }, pk)),
    J(Object.assign({ at: 1.8, ph: 'up',   p: [0.02, 0.40], t: 145, h: 25 }, pk))
  ] };

  var hl = { A: [-110, -110], B: [-105, -105], L: [112, 112], M: [112, 112], F: 180, G: 180 };
  H.hollow = { loop: 8, mat: true, thumb: 0, frames: [
    J(Object.assign({ at: 0, ph: 'hold', p: [0, 0.06], t: -60, h: 30 }, hl)),
    J(Object.assign({ at: 4, ph: 'hold', p: [0, 0.06], t: -55, h: 32, L: [108, 108], M: [108, 108] }, { A: hl.A, B: hl.B, F: 180, G: 180 }))
  ] };

  var sq = { t: 5, h: 0, A: [20, 25], B: [10, 20], L: [0.20, 0.025, 1], M: [-0.36, 0.46, 1], G: -85 };
  H.split = { loop: 4, mat: false, thumb: 1.6, props: [{ k: 'chair', x0: -0.62, x1: -0.30, h: 0.42 }], frames: [
    J(Object.assign({ at: 0,   ph: 'down', p: [-0.02, 0.47] }, sq)),
    J(Object.assign({ at: 1.6, ph: 'hold', p: [-0.03, 0.28] }, sq)),
    J(Object.assign({ at: 2.1, ph: 'up',   p: [-0.03, 0.28] }, sq))
  ] };
})();

;
// 15 yoga poses. Side-view mannequin, figure faces +x. See figure.js for the keyframe format.
(function () {
  var H = globalThis.HWPOSES = globalThis.HWPOSES || {};
  var J = function (o) { return Object.assign({ sp: 0, h: 0, F: 90, G: 90 }, o); };

  /* ---------- reusable keyframes for the sun salutation (all limbs IK) ---------- */
  var PRAYER = J({ p: [0, 0.508], t: 0, h: 0, A: [0.13, 0.68, -1], B: [0.15, 0.66, -1], L: [0, 0.02, 1], M: [0.05, 0.02, 1] });
  var ARMSUP = J({ p: [-0.02, 0.508], t: -6, sp: -8, h: -12, A: [-0.02, 1.11, -1], B: [0.0, 1.11, -1], L: [0, 0.02, 1], M: [0.05, 0.02, 1] });
  var FOLD = J({ p: [-0.12, 0.49], t: 158, h: 12, A: [0.12, 0.03, -1], B: [0.15, 0.03, -1], L: [0, 0.02, 1], M: [0.04, 0.02, 1] });
  var LUNGE = J({ p: [-0.10, 0.24], t: 75, h: -30, A: [0.22, 0.03, -1], B: [0.26, 0.03, -1], L: [0.26, 0.025, 1], M: [-0.50, 0.04, 1], G: 20 });
  var PLANK = J({ p: [0.0135, 0.242], t: 72.7, h: -20, A: [0.30, 0.03, -1], B: [0.33, 0.03, -1], L: [-0.45, 0.10, 1], M: [-0.45, 0.10, 1], F: 0, G: 0 });
  var COBRA = J({ p: [-0.12, 0.06], t: 42, sp: 10, h: -15, A: [0.20, 0.03, -1], B: [0.23, 0.03, -1], L: [-0.60, 0.035, 1], M: [-0.60, 0.035, 1], F: -90, G: -90 });
  var DOG = J({ p: [-0.05, 0.45], t: 133, h: 30, A: [0.40, 0.03, -1], B: [0.43, 0.03, -1], L: [-0.30, 0.03, 1], M: [-0.28, 0.03, 1] });
  function at(f, t, ph) { return Object.assign({ at: t, ph: ph }, f); }

  H.tadasana = { loop: 8, mat: true, thumb: 3.5, frames: [
    { at: 0, ph: 'in',   p: [0, 0.508], t: 0,  h: 0,  A: [6, 3],     L: [0, 0.02, 1] },
    { at: 3, ph: 'hold', p: [0, 0.508], t: -3, h: -8, A: [174, 178], L: [0, 0.02, 1] },
    { at: 5, ph: 'out',  p: [0, 0.508], t: -3, h: -8, A: [174, 178], L: [0, 0.02, 1] }
  ] };

  H.marjari = { loop: 6, mat: true, thumb: 0, frames: [
    { at: 0, ph: 'in',  s: [0.28, 0.34], t: 58,  sp: 52,  h: 40,  A: [0.28, 0.024, -1], L: [-0.27, 0.022, 1], F: -90 },
    { at: 3, ph: 'out', s: [0.28, 0.34], t: 102, sp: -40, h: -30, A: [0.28, 0.024, -1], L: [-0.27, 0.022, 1], F: -90 }
  ] };

  H.balasana = { loop: 8, mat: true, thumb: 3.5, frames: [
    J({ at: 0,   ph: 'in',  p: [-0.17, 0.07], t: 76, h: 35, A: [0.42, 0.03, 1], B: [0.44, 0.03, 1], L: [85, -90], M: [85, -90], F: -90, G: -90 }),
    J({ at: 3.5, ph: 'out', p: [-0.17, 0.07], t: 84, h: 35, A: [0.42, 0.03, 1], B: [0.44, 0.03, 1], L: [85, -90], M: [85, -90], F: -90, G: -90 })
  ] };

  var cob = { A: [0.10, 0.03, -1], B: [0.12, 0.03, -1], L: [-90, -90], M: [-90, -90], F: -90, G: -90 };
  H.bhujanga = { loop: 8, mat: true, thumb: 3.5, frames: [
    J(Object.assign({ at: 0,   ph: 'in',   p: [-0.15, 0.05], t: 78, h: 12 }, cob)),
    J(Object.assign({ at: 2.5, ph: 'hold', p: [-0.15, 0.05], t: 36, sp: 14, h: -12 }, cob)),
    J(Object.assign({ at: 5.5, ph: 'out',  p: [-0.15, 0.05], t: 36, sp: 14, h: -12 }, cob))
  ] };

  H.sukhasana = { loop: 8, mat: true, thumb: 0, props: [{ k: 'cushion', x: -0.2, w: 0.4, h: 0.05 }], frames: [
    { at: 0, ph: 'in',  p: [0, 0.12], t: 0,  sp: 0,  h: 0, A: [43, 43], L: [100, -75], M: [96, -100] },
    { at: 4, ph: 'out', p: [0, 0.12], t: -2, sp: -5, h: 0, A: [43, 43], L: [100, -75], M: [96, -100] }
  ] };

  H.surya = { loop: 15, mat: true, thumb: 1.5, frames: [
    at(PRAYER, 0, 'in'), at(ARMSUP, 1.5, 'out'), at(FOLD, 3, 'in'), at(LUNGE, 4.5, 'out'), at(PLANK, 6, 'hold'),
    at(COBRA, 7.5, 'in'), at(DOG, 9, 'out'), at(LUNGE, 10.5, 'in'), at(FOLD, 12, 'out'), at(ARMSUP, 13.5, 'in')
  ] };

  H.adho = { loop: 7, mat: true, thumb: 3.5, frames: [
    J({ at: 0,   ph: 'in',  p: [-0.05, 0.46], t: 132, h: 30, A: [0.40, 0.03, -1], B: [0.43, 0.03, -1], L: [-0.30, 0.03, 1], M: [-0.28, 0.03, 1] }),
    J({ at: 3.5, ph: 'out', p: [-0.05, 0.44], t: 134, h: 30, A: [0.40, 0.03, -1], B: [0.43, 0.03, -1], L: [-0.30, 0.03, 1], M: [-0.28, 0.03, 1] })
  ] };

  var w2 = { t: 0, h: 0, A: [90, 90], B: [-90, -90], L: [0.205, 0.025, 1], M: [-0.40, 0.02, 1] };
  H.vira2 = { loop: 8, mat: true, thumb: 3.5, frames: [
    J(Object.assign({ at: 0,   ph: 'in',   p: [-0.03, 0.34] }, w2)),
    J(Object.assign({ at: 3.5, ph: 'hold', p: [-0.03, 0.31] }, w2)),
    J(Object.assign({ at: 5.5, ph: 'out',  p: [-0.03, 0.31] }, w2))
  ] };

  var tri = { p: [0, 0.33], h: -55, A: [0.28, 0.10, -1], B: [180, 180], L: [0.38, 0.02, 1], M: [-0.38, 0.02, 1] };
  H.trikona = { loop: 8, mat: true, thumb: 3.5, frames: [
    J(Object.assign({ at: 0,   ph: 'in',   t: 70 }, tri)),
    J(Object.assign({ at: 3.5, ph: 'hold', t: 77 }, tri)),
    J(Object.assign({ at: 5.5, ph: 'out',  t: 77 }, tri))
  ] };

  var br = { A: [0.0, 0.03, -1], B: [0.03, 0.03, -1], L: [0.30, 0.025, 1], M: [0.32, 0.025, 1] };
  H.setu = { loop: 8, mat: true, thumb: 3, frames: [
    J(Object.assign({ at: 0, ph: 'up',   p: [0, 0.10], t: -92 }, br)),
    J(Object.assign({ at: 2, ph: 'hold', p: [0, 0.34], t: -128 }, br)),
    J(Object.assign({ at: 5, ph: 'down', p: [0, 0.34], t: -128 }, br))
  ] };

  var cr = { h: -45, A: [0.32, 0.03, -1], B: [0.35, 0.03, -1], L: [0.0, 0.17, 1], M: [0.03, 0.18, 1], F: 20, G: 20 };
  H.baka = { loop: 6, mat: true, thumb: 3, frames: [
    J(Object.assign({ at: 0, ph: 'in',  p: [0, 0.25], t: 76 }, cr)),
    J(Object.assign({ at: 3, ph: 'out', p: [0, 0.27], t: 82 }, cr))
  ] };

  var sp = { A: [0.30, 0.03, -1], B: [180, 180], L: [-0.45, 0.08, 1], M: [-0.47, 0.10, 1], h: -55 };
  H.vasistha = { loop: 8, mat: true, thumb: 3.5, frames: [
    J(Object.assign({ at: 0,   ph: 'in',   p: [0.0135, 0.23], t: 70 }, sp)),
    J(Object.assign({ at: 3.5, ph: 'hold', p: [0.0135, 0.255], t: 74 }, sp)),
    J(Object.assign({ at: 5.5, ph: 'out',  p: [0.0135, 0.255], t: 74 }, sp))
  ] };

  var hm = { p: [0, 0.45], t: 88, h: -55, A: [0.34, 0.14, -1], B: [180, 180], L: [0, 0.02, 1], G: 170 };
  H.ardha = { loop: 9, mat: true, thumb: 3, props: [{ k: 'block', x: 0.28, w: 0.14, h: 0.14 }], frames: [
    J(Object.assign({ at: 0,   ph: 'in',   M: [-30, -30] }, hm)),
    J(Object.assign({ at: 2.5, ph: 'hold', M: [-90, -90] }, hm)),
    J(Object.assign({ at: 5.5, ph: 'out',  M: [-90, -90] }, hm))
  ] };

  H.urdhva = { loop: 7, mat: true, thumb: 0, frames: [
    J({ at: 0,   ph: 'in',  p: [0, 0.47], t: 100, sp: 35, h: 25, A: [0.34, 0.03, -1], B: [0.37, 0.03, -1], L: [-0.15, 0.025, 1], M: [-0.13, 0.025, 1] }),
    J({ at: 3.5, ph: 'out', p: [0, 0.44], t: 104, sp: 30, h: 20, A: [0.34, 0.03, -1], B: [0.37, 0.03, -1], L: [-0.15, 0.025, 1], M: [-0.13, 0.025, 1] })
  ] };

  var hs = { A: [-0.04, 0.035, 1], B: [-0.02, 0.035, 1], L: [180, 180], M: [180, 180], F: 180, G: 180 };
  H.sirsa = { loop: 6, mat: true, thumb: 0, frames: [
    J(Object.assign({ at: 0, ph: 'hold', s: [0, 0.17], t: 177 }, hs)),
    J(Object.assign({ at: 3, ph: 'hold', s: [0, 0.17], t: 183 }, hs))
  ] };
})();

;
/* HealthyWorld: animated studio (yoga / exercises) and the home hero animation. Needs HWFig + HWPOSES loaded before this code. */
(function () {
  'use strict';
  var Fig = window.HWFig, POSES = window.HWPOSES || {};
  if (!Fig) return;
  var reduce = !!(window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches);
  function $(id) { return document.getElementById(id); }

  /* ---- home hero: loops quietly while visible ---- */
  var hero = $('heroStage');
  if (hero && POSES[hero.getAttribute('data-pose')]) {
    var hc = Fig.mount(hero, POSES[hero.getAttribute('data-pose')], { label: hero.getAttribute('data-label') || '', autoplay: false });
    if (!reduce) {
      if ('IntersectionObserver' in window) {
        new IntersectionObserver(function (es) { es.forEach(function (e) { if (e.isIntersecting) hc.play(); else hc.pause(); }); }, { threshold: 0.2 }).observe(hero);
      } else hc.play();
    }
  }

  /* ---- studio ---- */
  var dataEl = $('hw-data');
  if (!dataEl) return;
  var D = JSON.parse(dataEl.textContent), I = D.i18n, order = Object.keys(D.poses);
  var stage = $('stage'), phase = $('phase'), round = $('round'), btn = $('btnPlay'), note = $('motionNote');
  var cur = null, ctl = null, userPaused = false;

  function phaseText(ph) { return I['ph_' + ph] || ''; }
  function pipsHtml(l, name) {
    return '<span class="pips"><span class="pip-dots" aria-hidden="true">' + [1, 2, 3].map(function (n) { return '<i' + (n <= l ? ' class="on"' : '') + '></i>'; }).join('') + '</span><span class="pip-l">' + name + '</span></span>';
  }
  function setBtn(playing) { btn.textContent = playing ? I.st_pause : I.st_play; btn.setAttribute('aria-pressed', playing ? 'true' : 'false'); }

  function select(id, opts) {
    opts = opts || {};
    if (!D.poses[id] || !POSES[id]) return;
    var p = D.poses[id];
    cur = id;
    round.textContent = '';
    $('stName').textContent = p.name;
    $('stSa').textContent = p.sa;
    $('stDose').innerHTML = p.dose;
    $('stPips').innerHTML = pipsHtml(p.lvl, p.lvlName);
    $('stDesc').textContent = p.desc;
    var cards = document.querySelectorAll('.pcard');
    for (var i = 0; i < cards.length; i++) { if (cards[i].getAttribute('data-id') === id) cards[i].setAttribute('aria-current', 'true'); else cards[i].removeAttribute('aria-current'); }
    if (!ctl) {
      ctl = Fig.mount(stage, POSES[id], {
        label: p.name, autoplay: false,
        onphase: function (ph) { phase.textContent = phaseText(ph); },
        onloop: function (n) { round.textContent = I.st_round + ' ' + (n + 1); },
        onstate: setBtn
      });
      round.textContent = I.st_round + ' 1';
    } else {
      ctl.set(POSES[id], p.name);
      round.textContent = I.st_round + ' 1';
    }
    if (reduce || userPaused) { ctl.pause(); setBtn(false); if (reduce && note) note.hidden = false; } else ctl.play();
    if (opts.scroll) { var card = $('stageCard'); if (card && window.matchMedia && matchMedia('(max-width: 899px)').matches) card.scrollIntoView({ behavior: reduce ? 'auto' : 'smooth', block: 'start' }); }
    if (opts.hash && history.replaceState) { try { history.replaceState(null, '', '#' + id); } catch (e) {} }
  }

  btn.addEventListener('click', function () {
    if (!ctl) return;
    if (ctl.playing()) { userPaused = true; ctl.pause(); } else { userPaused = false; ctl.play(); }
  });
  var speedSeg = $('speedSeg');
  speedSeg.addEventListener('click', function (e) {
    var b = e.target.closest('button[data-s]'); if (!b || !ctl) return;
    ctl.speed(parseFloat(b.getAttribute('data-s')));
    var bs = speedSeg.querySelectorAll('button'); for (var i = 0; i < bs.length; i++) bs[i].setAttribute('aria-pressed', bs[i] === b ? 'true' : 'false');
  });

  var lvlSeg = $('lvlSeg');
  lvlSeg.addEventListener('click', function (e) {
    var b = e.target.closest('button[data-lvl]'); if (!b) return;
    var l = parseInt(b.getAttribute('data-lvl'), 10), bs = lvlSeg.querySelectorAll('button');
    for (var i = 0; i < bs.length; i++) bs[i].setAttribute('aria-pressed', bs[i] === b ? 'true' : 'false');
    var cards = document.querySelectorAll('.pcard');
    for (var j = 0; j < cards.length; j++) cards[j].hidden = !(l === 0 || parseInt(cards[j].getAttribute('data-lvl'), 10) === l);
  });

  $('plist').addEventListener('click', function (e) {
    var c = e.target.closest('.pcard'); if (!c) return;
    userPaused = false;
    select(c.getAttribute('data-id'), { scroll: true, hash: true });
  });
  document.addEventListener('click', function (e) {
    var a = e.target.closest('a[data-pose]'); if (!a) return;
    e.preventDefault(); userPaused = false;
    select(a.getAttribute('data-pose'), { scroll: true, hash: true });
  });

  var start = (location.hash || '').replace('#', '');
  select(D.poses[start] ? start : D.first, { hash: false });
  window.addEventListener('hashchange', function () { var h = (location.hash || '').replace('#', ''); if (D.poses[h] && h !== cur) { userPaused = false; select(h, { scroll: true }); } });
  document.addEventListener('visibilitychange', function () { if (!ctl) return; if (document.hidden) ctl.pause(); else if (!reduce && !userPaused) ctl.play(); });
})();
